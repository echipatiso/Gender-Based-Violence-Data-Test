# Gender-Based-Violence-Data-Test
This is a simple web map showing the spatial distribution of Gender-Based Violence (GBV) Incidents and support services in Mutoko District.
https://echipatiso.github.io/Gender-Based-Violence-Data-Test/
